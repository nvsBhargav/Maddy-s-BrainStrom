import React from 'react';
import { GridNodeData } from '../types';

interface ConnectingLinesProps {
  nodes: GridNodeData[];
}

export const ConnectingLines: React.FC<ConnectingLinesProps> = React.memo(({ nodes }) => {
  return (
    <svg 
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 0,
        overflow: 'visible'
      }}
    >
      {nodes.map(node => {
        if (!node.parentId) return null;
        
        const parent = nodes.find(n => n.id === node.parentId);
        if (!parent) return null;

        // Parent connection point: right side, vertical middle
        const startX = parent.x + parent.width;
        const parentCenterY = parent.height ? parent.height / 2 : 190;
        const nodeCenterY = node.height ? node.height / 2 : 190;
        const startY = parent.y + parentCenterY; 
        const endX = node.x; 
        const endY = node.y + nodeCenterY;

        // Create a horizontal sweeping bezier curve (continuous, flexible)
        const cp1X = startX + (endX - startX) / 2;
        const cp1Y = startY;
        const cp2X = cp1X;
        const cp2Y = endY;

        return (
          <g key={`line-group-${node.id}`}>
            {/* White continuous flexible bezier connection as requested */}
            <path
              d={`M ${startX} ${startY} C ${cp1X} ${cp1Y}, ${cp2X} ${cp2Y}, ${endX} ${endY}`}
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="4"
              strokeLinecap="round"
              className="drop-shadow-[0_0_6px_rgba(255,255,255,0.4)]"
            />
            {/* White endpoint discs */}
            <circle cx={startX} cy={startY} r="5" fill="#FFFFFF" />
            <circle cx={endX} cy={endY} r="5" fill="#FFFFFF" />
          </g>
        );
      })}
    </svg>
  );
});

ConnectingLines.displayName = 'ConnectingLines';
